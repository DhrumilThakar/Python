from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegistrationForm, LoginForm, GroupForm, JoinGroupForm, ExpenseForm
from .models import UserProfile, Group, Expense
from django.contrib.auth.models import User
from django.db.models import Sum, F, Q
from django.http import HttpResponseForbidden

def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user)
            login(request, user)
            return redirect('dashboard')
    else:
        form = RegistrationForm()
    return render(request, 'expenses/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                # Ensure userprofile exists
                if not hasattr(user, 'userprofile'):
                    UserProfile.objects.create(user=user)
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Invalid username or password')
    else:
        form = LoginForm()
    return render(request, 'expenses/login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard_view(request):
    try:
        user_profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        # Create UserProfile if it does not exist
        user_profile = UserProfile.objects.create(user=request.user)

    if not user_profile.group:
        return redirect('create_group')

    group = user_profile.group
    expenses = Expense.objects.filter(group=group).order_by('-date')[:10]

    # Calculate balances
    balances = {member.username: 0 for member in User.objects.filter(userprofile__group=group)}

    for expense in expenses:
        split_amount = expense.amount / expense.shared_among.count()
        for user in expense.shared_among.all():
            if user == expense.paid_by:
                balances[user.username] += expense.amount - split_amount
            else:
                balances[user.username] -= split_amount

    # Prepare who owes whom
    owes = []
    processed = set()
    for user in balances:
        for other in balances:
            if user != other and (other, user) not in processed:
                net = balances[user] - balances[other]
                if net > 0:
                    owes.append({'from': other, 'to': user, 'amount': net})
                elif net < 0:
                    owes.append({'from': user, 'to': other, 'amount': abs(net)})
                processed.add((user, other))

    context = {
        'group': group,
        'expenses': expenses,
        'balances': balances,
        'owes': owes,
    }
    return render(request, 'expenses/dashboard.html', context)

@login_required
def create_group_view(request):
    user_profile = request.user.userprofile
    if user_profile.group:
        return redirect('dashboard')

    if request.method == 'POST':
        form = GroupForm(request.POST)
        if form.is_valid():
            group = Group.objects.create(name=form.cleaned_data['name'])
            user_profile.group = group
            user_profile.save()
            return redirect('dashboard')
    else:
        form = GroupForm()
    return render(request, 'expenses/create_group.html', {'form': form})

@login_required
def join_group_view(request):
    user_profile = request.user.userprofile
    if user_profile.group:
        return redirect('dashboard')

    if request.method == 'POST':
        form = JoinGroupForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['code'].upper()
            try:
                group = Group.objects.get(code=code)
                user_profile.group = group
                user_profile.save()
                return redirect('dashboard')
            except Group.DoesNotExist:
                messages.error(request, 'Invalid group code')
    else:
        form = JoinGroupForm()
    return render(request, 'expenses/join_group.html', {'form': form})

@login_required
def add_expense_view(request):
    user_profile = request.user.userprofile
    if not user_profile.group:
        return redirect('create_group')

    if request.method == 'POST':
        form = ExpenseForm(request.POST, user=request.user)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.group = user_profile.group
            expense.save()
            form.save_m2m()
            return redirect('dashboard')
    else:
        form = ExpenseForm(user=request.user)
    return render(request, 'expenses/add_expense.html', {'form': form})

@login_required
def expense_list_view(request):
    user_profile = request.user.userprofile
    if not user_profile.group:
        return redirect('create_group')

    expenses = Expense.objects.filter(group=user_profile.group).order_by('-date')
    return render(request, 'expenses/expense_list.html', {'expenses': expenses})

@login_required
def edit_expense_view(request, expense_id):
    user_profile = request.user.userprofile
    expense = get_object_or_404(Expense, id=expense_id)
    if expense.paid_by != request.user:
        return HttpResponseForbidden("You are not allowed to edit this expense.")

    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense, user=request.user)
        if form.is_valid():
            form.save()
            return redirect('expense_list')
    else:
        form = ExpenseForm(instance=expense, user=request.user)
    return render(request, 'expenses/edit_expense.html', {'form': form})

@login_required
def delete_expense_view(request, expense_id):
    user_profile = request.user.userprofile
    expense = get_object_or_404(Expense, id=expense_id)
    if expense.paid_by != request.user:
        return HttpResponseForbidden("You are not allowed to delete this expense.")

    if request.method == 'POST':
        expense.delete()
        return redirect('expense_list')
    return render(request, 'expenses/delete_expense.html', {'expense': expense})