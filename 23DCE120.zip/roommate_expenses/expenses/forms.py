from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Expense

class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already exists.")
        return username

    def clean_password1(self):
        password = self.cleaned_data.get('password1')
        if len(password) < 8:
            raise forms.ValidationError("Password must be at least 8 characters long.")
        if not any(c.isdigit() for c in password):
            raise forms.ValidationError("Password must contain at least one number.")
        if not any(c.isalpha() for c in password):
            raise forms.ValidationError("Password must contain at least one letter.")
        return password

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

class GroupForm(forms.Form):
    name = forms.CharField(max_length=100)

class JoinGroupForm(forms.Form):
    code = forms.CharField(max_length=10)

class ExpenseForm(forms.ModelForm):
    shared_among = forms.ModelMultipleChoiceField(
        queryset=User.objects.none(),
        widget=forms.CheckboxSelectMultiple
    )

    class Meta:
        model = Expense
        fields = ['title', 'amount', 'paid_by', 'shared_among']

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        if user.userprofile.group:
            group_users = user.userprofile.group.userprofile_set.all().values_list('user', flat=True)
            self.fields['shared_among'].queryset = User.objects.filter(id__in=group_users)
            self.fields['paid_by'].queryset = User.objects.filter(id__in=group_users)
        else:
            self.fields['shared_among'].queryset = User.objects.none()
            self.fields['paid_by'].queryset = User.objects.none()
