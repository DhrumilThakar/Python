from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('group/create/', views.create_group_view, name='create_group'),
    path('group/join/', views.join_group_view, name='join_group'),
    path('expenses/add/', views.add_expense_view, name='add_expense'),
    path('expenses/', views.expense_list_view, name='expense_list'),
    path('expenses/edit/<int:expense_id>/', views.edit_expense_view, name='edit_expense'),
    path('expenses/delete/<int:expense_id>/', views.delete_expense_view, name='delete_expense'),
]
